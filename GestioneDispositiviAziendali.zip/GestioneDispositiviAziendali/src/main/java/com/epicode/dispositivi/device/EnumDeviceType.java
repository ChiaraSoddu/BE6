package com.epicode.dispositivi.device;

public enum EnumDeviceType {
	SMARTPHONE,
	TABLET,
	LAPTOP
}
