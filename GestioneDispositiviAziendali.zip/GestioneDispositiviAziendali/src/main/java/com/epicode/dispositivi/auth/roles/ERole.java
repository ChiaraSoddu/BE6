package com.epicode.dispositivi.auth.roles;

public enum ERole {
	ROLE_ADMIN,
	ROLE_USER;
}
