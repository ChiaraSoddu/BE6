package com.epicode.dispositivi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestioneDispositiviAziendaliApplicationTests {

	@Test
	void contextLoads() {
	}

}
