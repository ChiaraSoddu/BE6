package com.epicode.dispositivi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestioneDispositiviAziendaliApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestioneDispositiviAziendaliApplication.class, args);
	}

}
