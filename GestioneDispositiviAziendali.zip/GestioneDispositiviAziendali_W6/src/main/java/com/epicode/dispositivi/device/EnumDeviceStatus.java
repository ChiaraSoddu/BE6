package com.epicode.dispositivi.device;

public enum EnumDeviceStatus {
	AVAILABLE,
	ASSIGNED,
	MAINTENANCE,
	DISMISSED
}
